import { IconLayer } from "@deck.gl/layers";
import { aircraftData } from "../icon/aircraftData";
import aircraftsPhoto from "../icon/aircraftSprite.png";

export function createAircraftLayer(data) {
  return new IconLayer({
    id: "aircraft-icon-layer",
    data,
    pickable: true,
    iconAtlas: aircraftsPhoto,
    iconMapping: aircraftData,
    getIcon: () => "commercial_airliner",
    sizeScale: 15,
    sizeUnits: "pixels", // Add this to ensure size is in pixels
    getPosition: (d) => {
      // Force coordinates to be numbers!
      return [
        parseFloat(d.lon),
        parseFloat(d.lat),
        parseFloat(d.altitude_ft) || 0,
      ];
    },
    getSize: () => 3,
    // getColor: () => [255, 215, 0], // 🔴 Comment this out temporarily to test
    getAngle: (d) => -(parseFloat(d.heading) || 0),
  });
}
