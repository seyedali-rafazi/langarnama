import DeckGLOverlay from "../../../../components/map/components/DeckGLOverlay/DeckGLOverlay";
import aircraftData from "./data/iran_aircraft_50.json";
import { createAircraftIconLayer } from "./layers/createAircraftLayer";

const AircraftLayer = () => {
  const layers = [
    createAircraftIconLayer(aircraftData),
    // Later you can easily add more layers here:
    // createWeatherLayer(weatherData),
    // createFlightPathLayer(pathsData)
  ];

  return <DeckGLOverlay layers={layers} />;
};

export default AircraftLayer;
