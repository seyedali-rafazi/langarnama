import { Box } from "@mui/material";
import MapboxMap from "../../components/map/AsemanhaMap";
import AircraftLayer from "./components/AircraftLayer/AircraftLayer";

const HomePage = () => {
  return (
    <Box sx={{ p: 4 }}>
      <MapboxMap>
        <AircraftLayer />
      </MapboxMap>
    </Box>
  );
};

export default HomePage;
