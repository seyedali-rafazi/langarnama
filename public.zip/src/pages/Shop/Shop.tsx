import { useState } from "react";
import * as Icons from "@mui/icons-material";
import { TextField } from "@mui/material";

function IconBrowser() {
  const [search, setSearch] = useState("");
  const iconNames = Object.keys(Icons).filter((name) =>
    name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ padding: "20px" }}>
      <TextField
        fullWidth
        label="Search icons"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ marginBottom: "20px" }}
      />

      <div style={{ display: "flex", flexWrap: "wrap", gap: "16px" }}>
        {iconNames.map((iconName) => {
          const Icon = Icons[iconName];
          return (
            <div key={iconName} style={{ textAlign: "center", width: "80px" }}>
              <Icon />
              <p style={{ fontSize: "10px" }}>{iconName}</p>
            </div>
          );
        })}
      </div>
      <p style={{ marginTop: "20px" }}>Found: {iconNames.length} icons</p>
    </div>
  );
}

export default IconBrowser;
