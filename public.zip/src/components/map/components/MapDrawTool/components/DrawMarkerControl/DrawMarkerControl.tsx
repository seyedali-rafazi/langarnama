import { Box } from "@mui/material";
import { useState } from "react";
import MarkerButton from "./components/MarkerButton";
import MarkerModal from "./components/MarkerModal";

const DrawMarkerControl = () => {
  const [isDrawing, setIsDrawing] = useState(false);

  return (
    <Box sx={{ display: "flex", flexDirection: "column", gap: 1 }}>
      <MarkerButton isDrawing={isDrawing} setIsDrawing={setIsDrawing} />
      <MarkerModal isDrawing={isDrawing} setIsDrawing={setIsDrawing} />
    </Box>
  );
};

export default DrawMarkerControl;
