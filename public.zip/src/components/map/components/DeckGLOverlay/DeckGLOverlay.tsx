import { useEffect, useRef } from "react";
import { MapboxOverlay } from "@deck.gl/mapbox";
import { useMap } from "react-map-gl/mapbox";

export default function DeckGLOverlay({ layers }) {
  const { current: map } = useMap();
  const overlayRef = useRef(null);

  useEffect(() => {
    if (!map) return;

    if (!overlayRef.current) {
      overlayRef.current = new MapboxOverlay({
        interleaved: true,
      });

      map.addControl(overlayRef.current);
    }

    overlayRef.current.setProps({ layers });
  }, [map, layers]);

  return null;
}
