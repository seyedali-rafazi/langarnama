import {
  Box,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
} from "@mui/material";
import { createContext, useContext, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const COLLAPSED_WIDTH = 80;
const EXPANDED_WIDTH = 380;

// 1. Create the Context
const SidebarContext = createContext(null);

// 2. Create the Custom Hook
export const useSidebar = () => {
  const context = useContext(SidebarContext);
  if (!context) {
    throw new Error("useSidebar must be used within a SidebarProvider");
  }
  return context;
};

// 3. Create the Provider Component
export const SidebarProvider = ({ children, config }) => {
  const navigate = useNavigate();
  const location = useLocation();

  const [isExpanded, setIsExpanded] = useState(false);
  const [activeComponentId, setActiveComponentId] = useState(null);

  // --- Core Functions for the Hook ---

  const openSidebar = (id) => {
    const item = config.find((i) => i.id === id);
    if (item && item.component) {
      setIsExpanded(true);
      setActiveComponentId(id);
    }
  };

  const closeSidebar = () => {
    setIsExpanded(false);
    setActiveComponentId(null);
  };

  const toggleSidebar = (id) => {
    if (isExpanded && activeComponentId === id) {
      closeSidebar();
    } else {
      openSidebar(id);
    }
  };

  const handleSidebarClick = (item) => {
    if (item.navigate) {
      closeSidebar();
      navigate(item.navigate);
    } else if (item.component) {
      toggleSidebar(item.id);
    }
  };

  // --- Separate items by position ---
  const topItems = config.filter(
    (item) => item.position === "top" || !item.position
  );
  const bottomItems = config.filter((item) => item.position === "bottom");

  const renderList = (items) => (
    <List>
      {items.map((item) => {
        const isActive =
          activeComponentId === item.id || location.pathname === item.navigate;

        return (
          <ListItem
            key={item.id}
            disablePadding
            sx={{ display: "block", mb: 1 }}
          >
            <ListItemButton
              onClick={() => handleSidebarClick(item)}
              sx={{
                minHeight: 60,
                justifyContent: "center",
                flexDirection: "column",
                px: 1,
                borderRadius: 2,
                mx: 1,
                bgcolor: isActive ? "action.selected" : "transparent",
                "&:hover": { bgcolor: "action.hover" },
                color: isActive ? "primary.main" : "text.secondary",
              }}
            >
              {item.icon}
              <ListItemText
                primary={item.textButton}
                primaryTypographyProps={{
                  variant: "caption",
                  fontWeight: isActive ? "bold" : "normal",
                  color: isActive ? "primary.main" : "text.secondary",
                }}
                sx={{ m: 0, textAlign: "center" }}
              />
            </ListItemButton>
          </ListItem>
        );
      })}
    </List>
  );

  return (
    // Pass state and functions to the rest of the app
    <SidebarContext.Provider
      value={{
        isExpanded,
        activeComponentId,
        openSidebar,
        closeSidebar,
        toggleSidebar,
      }}
    >
      <Box sx={{ display: "flex", height: "100vh", overflow: "hidden" }}>
        {/* The Sidebar UI */}
        <Drawer
          variant="permanent"
          sx={{
            width: isExpanded ? EXPANDED_WIDTH : COLLAPSED_WIDTH,
            flexShrink: 0,
            "& .MuiDrawer-paper": {
              width: isExpanded ? EXPANDED_WIDTH : COLLAPSED_WIDTH,
              overflowX: "hidden",
              display: "flex",
              flexDirection: "row",
              transition: (theme) =>
                theme.transitions.create("width", {
                  easing: theme.transitions.easing.sharp,
                  duration: theme.transitions.duration.enteringScreen,
                }),
            },
          }}
        >
          {/* Left Rail (Buttons) */}
          <Box
            sx={{
              width: COLLAPSED_WIDTH,
              height: "100%",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              borderRight: "1px solid",
              borderColor: "divider",
              flexShrink: 0,
              py: 2,
              backgroundColor: "background.paper",
            }}
          >
            <Box>{renderList(topItems)}</Box>
            <Box>{renderList(bottomItems)}</Box>
          </Box>

          {/* Expanded Component Area */}
          <Box
            sx={{
              width: EXPANDED_WIDTH - COLLAPSED_WIDTH,
              height: "100%",
              flexShrink: 0,
              p: 3,
              bgcolor: "background.default",
            }}
          >
            {config.find((i) => i.id === activeComponentId)?.component}
          </Box>
        </Drawer>

        {/* Main Application Content Wrapper */}
        <Box component="main" sx={{ flexGrow: 1, overflow: "auto" }}>
          {children}
        </Box>
      </Box>
    </SidebarContext.Provider>
  );
};
