import {
  AirplanemodeActive,
  FeaturedPlayList,
  HomeOutlined,
  Settings,
} from "@mui/icons-material";
import {
  Box,
  createTheme,
  CssBaseline,
  ThemeProvider,
  Typography,
} from "@mui/material";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster } from "sonner";
import { SidebarProvider } from "./components/utils/Sidebar/SidebarProvider";
import HomePage from "./pages/Home/Home";
import ShopPage from "./pages/Shop/Shop";

// ✅ Custom MUI Theme
const theme = createTheme({
  palette: {
    background: {
      paper: "#1d1f20",
    },
    primary: {
      main: "#1976d2",
    },
    text: {
      secondary: "#fff",
      primary: "#8b8b8b8d",
    },
    grey: { A100: "#313131ff" },
  },
  shape: {
    borderRadius: 10,
  },
});

// --- Sidebar Panel Components ---
const FeatureComponent = () => (
  <Box>
    <Typography variant="h6">Feature Settings</Typography>
    <Typography variant="body2" sx={{ mt: 2 }}>
      Feature controls go here...
    </Typography>
  </Box>
);

const SettingComponent = () => (
  <Box>
    <Typography variant="h6">App Settings</Typography>
    <Typography variant="body2" sx={{ mt: 2 }}>
      Profile, Theme, and Language...
    </Typography>
  </Box>
);

// --- The Sidebar Configuration ---
const sidebarConfig = [
  {
    id: "home",
    textButton: "Home",
    position: "top",
    navigate: "/",
    icon: <HomeOutlined />,
  },
  {
    id: "airplane",
    textButton: "Airplane",
    position: "top",
    navigate: "/airplane",
    icon: <AirplanemodeActive />,
  },
  {
    id: "feature",
    textButton: "Feature",
    component: <FeatureComponent />,
    position: "top",
    icon: <FeaturedPlayList />,
  },
  {
    id: "setting",
    textButton: "Setting",
    component: <SettingComponent />,
    position: "bottom",
    icon: <Settings />,
  },
];

// --- Main App Root ---
export default function App() {
  return (
    <BrowserRouter>
      <Toaster richColors position="top-right" />
      <CssBaseline />
      <ThemeProvider theme={theme}>
        <SidebarProvider config={sidebarConfig}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/airplane" element={<ShopPage />} />
          </Routes>
        </SidebarProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
